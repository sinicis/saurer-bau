<b>Die Firma</b>

</br></br>

Unser Firma wurde 2013 gegründet. Zurzeit arbeiten in unserer Firma 3 qualifizierte Mitarbeiter, welche allesamt wohnhaft in Oberhofen sind.</br></br>

Unsere Spezialgebiete sind Neubauten, An-/und Umbauten, Kundenmaurerarbeiten, Umgebungsarbeiten wie St&uuml;tzmauern
sowie Vorpl&auml;tze.

</br></br>

Das Team kurz vorgestellt:</br></br>

<table width='100%'>
    <tr>
        <td height='150px' align='center'><img src='../images/no-avatar.png' width='150px' /></td>
        <td height='150px' align='center'><img src='../images/no-avatar.png' width='150px' /></td>
        <td height='150px' align='center'><img src='../images/no-avatar.png' width='150px' /></td>
    </tr>
    <tr><td></br></td></tr>
    <tr>
        <td valign='top' align='center'>
            Lorenz Saurer</br>
            dipl. Bauf&uuml;hrer SBA</br>
            Kundenmaurer
        </td>
        <td valign='top' align='center'>
            Bruno Saurer</br>
            Hochbaupolier
        </td>
        <td valign='top' align='center'>
            Giorgio Caporale</br>
            Kundenmaurer
        </td>
    </tr>
</table>

