<b>Kontakt</b>

<p>
Saurer Bau GmBH Oberhofen<br />
Schulthesserstrasse 2<br />
3653 Oberhofen am Thunersee<br />
+41 79 656 67 70<br />
lorenz.saurer@bluewin.ch <br />
</p>
<center>
<!--<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2734.712909694215!2d7.669896173402406!3d46.73112377867839!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478fb20dcfa750f7%3A0xf1b2941c091dedaa!2sSchulthesserstrasse+2!5e0!3m2!1sde!2sch!4v1398520761250" width="500" height="300" frameborder="0" style="border:0"></iframe>-->
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2823.0403194694495!2d7.669896173402418!3d46.731123799329055!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478fb20dcfa750f7%3A0xf1b2941c091dedaa!2sSchulthesserstrasse+2!5e1!3m2!1sde!2sch!4v1398520845416" width="500" height="300" frameborder="0" style="border:0"></iframe>
</center>
