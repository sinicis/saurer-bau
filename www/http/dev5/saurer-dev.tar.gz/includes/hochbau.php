<b>Hochbau</b>

</br></br>
<b>DEFH Unterdorstrasse, Tschingel</b></br></br>
<object data='gallery/hochbau/1/index.html' width='100%' height='400px'></object>


</br></br>
<b>MFH Wenger, Oberhofen (Fr&uuml;hjahr 2015)</b></br></br>
<object data='gallery/hochbau/2/index.html' width='100%' height='400px'></object>

